# Handoff: Storyjar Sticker Feedback — Sticker Sheet (1b) & Child View (1d)

## Overview
Storyjar lets a teacher attach a warm, specific sticker to a child's "moment" (a piece of
work) when adding it to that child's jar; the child later sees the sticker arrive. This
package covers **two screens** of that flow:

- **1b — The sticker sheet**: the teacher's full-size compose view. Open a moment, pick
  from a real sheet of stickers sorted by kind (Praise / Skills / Feelings / Milestones),
  peel up to 4 onto the work, add a note, and drop it in the jar.
- **1d — What the child sees**: the payoff. When the child opens their jar, the sticker
  drops gently onto the moment with the teacher's note; the child can send one back.

The stickers are a custom **hand-inked icon set** (not emoji), each a puffy die-cut badge.
A subset are **holographic** — an animated rainbow foil that shimmers.

## About the Design Files
The files in this bundle are **design references authored in HTML** (a lightweight
component runtime — `.dc.html` files rendered by `support.js`). They are prototypes that
demonstrate the intended look and behavior; they are **not** production code to ship as-is.

Your task is to **recreate these designs in the target codebase's existing environment**
(React, Vue, SwiftUI, native, etc.) using its established components, tokens, and patterns.
If no front-end environment exists yet, pick the most appropriate framework for the project
and implement there. Treat `Sticker.dc.html` / `Sticker Feedback.dc.html` as the source of
truth for measurements, colors, copy, and motion.

## Fidelity
**High-fidelity.** Colors, typography, spacing, iconography, and interactions are final.
Recreate the UI pixel-accurately using the codebase's libraries. The sticker glyphs are
drawn as inline SVG on a 24×24 keyline grid — reproduce the exact path data (see
`Sticker.dc.html`, `icon(k)` method).

---

## Screens / Views

### 1b — The Sticker Sheet

**Purpose:** Teacher composes feedback on one moment and adds it to the jar.

**Layout:** A single card, `max-width` unconstrained (design column 680px).
- Card: `background #FFFDF7; border 2px solid #DFD6C0; border-radius 18px; padding 18px;
  box-shadow 0 12px 30px rgba(34,48,74,.10)`.
- Inside: CSS grid, `grid-template-columns: 232px 1fr; gap: 18px`.
  - **Left column (232px)** — the work preview + note + submit:
    - Preview tile: `height 200px; border-radius 14px; background #FBEED3;
      border 3px solid #22304A; position: relative` (holds the artwork; placed stickers
      are absolutely positioned over it). Artwork in the mock is a placeholder glyph.
    - Title: `Fredoka 600 16px #22304A` — e.g. "Nell · our sunflower diary".
    - Subtitle: `Atkinson Hyperlegible 400 13px #6B7690` — e.g. "Science · 2:15 this afternoon".
    - Note input: full width, `margin-top 12px; font 400 13px Atkinson; padding 9px 12px;
      border 2px solid #E4DCC8; border-radius 10px; background #FAF6EE; color #22304A`.
      Placeholder: "A note to Nell (optional)…".
    - Submit button: full width, `margin-top 10px; Fredoka/Atkinson 700 15px; color #FAF6EE;
      background #4E9C94; border none; border-radius 999px; padding 12px;
      box-shadow 0 3px 0 #35706A`. Label changes with placement count (see below).
  - **Right column (1fr)** — the sticker sheet:
    - **Category tabs** row (`display:flex; gap:6px; margin-bottom:12px`). Four pill buttons:
      Praise, Skills, Feelings, Milestones. `font 700 13px Atkinson; border-radius 999px;
      padding 6px 13px; border 2px solid`.
      - Selected: `background #22304A; color #FAF6EE; border #22304A`.
      - Unselected: `background #FFFDF7; color #43506B; border #E4DCC8`.
    - **Sheet grid:** `background #FAF6EE; border 2px dashed #DFD6C0; border-radius 12px;
      padding 14px; display:grid; grid-template-columns: repeat(3, 1fr); gap: 14px 8px;
      min-height 168px; align-content: start`. Shows the **6 stickers** of the active tab.
      - Each cell is a button: `flex column; align-items center; gap 5px; background none;
        border none; cursor pointer`. Contains a **Sticker** (size 52) + a label
        (`font 700 11px Atkinson; color #43506B; text-align center; line-height 1.15`).
      - A selected/placed sticker shows the Sticker component's `selected` ring (see Sticker spec).
    - **Hint line** under the grid: `font 400 12px Atkinson; color #6B7690`.
      - When nothing placed: "Tap a sticker to peel it onto the work (up to 4)."
      - When N placed: "N of 4 placed · tap a placed sticker to remove".

**Behavior (1b):**
- Tapping a category tab swaps the 6 stickers shown.
- Tapping a sheet sticker **peels it onto the work**: it appears absolutely positioned over
  the preview tile at one of 4 preset spots, animating in with `stkPop`. Max 4 placed.
- Tapping an already-placed sticker (in the sheet) **removes** it from the work.
- Placed sticker spots (top/left offsets relative to the 232px preview tile, with a tilt
  CSS var `--tilt` consumed by `stkPop`):
  1. `top:-18px; left:18px; --tilt:-9deg`
  2. `top:92px; left:-20px; --tilt:7deg`
  3. `top:112px; left:150px; --tilt:-6deg`
  4. `top:-16px; left:150px; --tilt:8deg`
- Submit button label: `Add to jar` when empty; `✓ Add to jar with N sticker(s)` when N placed.
- Submitting clears placed stickers + note (in the mock; wire to real persistence in-app).

### 1d — What the Child Sees

**Purpose:** The child opens their jar and receives the sticker + note; can send one back.

**Layout:** A dark panel container.
- Outer panel: `background #22304A; border-radius 18px; padding 26px;
  box-shadow 0 12px 30px rgba(34,48,74,.16)`.
- **Header row** (`flex; align-items center; gap 12px; margin-bottom 18px`):
  - Avatar: `46px circle; background #E08A9B; Fredoka 600 22px #FFFDF7`; content is initial ("P").
  - Title: `Fredoka 600 20px #FAF6EE` — "Poppy's jar".
  - Subtitle: `Atkinson 400 14px #A9B4C9` — "A new sticker just arrived".
  - "Play again" button (`margin-left:auto; Atkinson 700 13px; color #22304A;
    background #F0B441; border none; border-radius 999px; padding 9px 16px`) — replays the
    drop animation.
- **Inner card** (`background #FAF6EE; border-radius 14px; padding 22px; display:flex;
  gap 22px; align-items center`):
  - **Left — the moment** (`width 200px; position relative`):
    - Card: `background #FFFDF7; border 3px solid #22304A; border-radius 16px; overflow hidden;
      box-shadow 0 4px 0 rgba(34,48,74,.12)`. On arrival it plays `jarBump` (transform-origin
      top center).
      - Image band: `height 118px; background #FBEED3` (artwork placeholder glyph).
      - Caption block `padding 12px 14px`: title `Fredoka 600 17px` ("My rainbow"); date
        `Atkinson 400 13px #6B7690` ("Tuesday 7 July").
    - **Dropped sticker**: absolutely positioned `top:-20px; right:-18px`, a **holographic**
      Sticker (`k="best"`, `size 68`) that plays `stkDrop` (0.9s) to land on the card.
  - **Right — the message** (`flex:1`):
    - "From" tab: inline-block, `background #F3E3C3; border 3px solid #22304A;
      border-radius 8px 14px 14px 8px; padding 7px 16px; transform rotate(-2deg);
      Fredoka 600 15px` — "From Miss M".
    - Message: `Atkinson 400 21px/1.4 #22304A` — the teacher's note (quoted).
    - "Send one back" button: `margin-top 18px; Fredoka 600 17px; color #FAF6EE;
      background #C2476B; border 3px solid #22304A; border-radius 999px; padding 11px 24px;
      box-shadow 0 4px 0 #93304F`. On click it becomes a confirmation state
      ("💛 Sent a heart back!" in the mock — replace glyph with the app's heart icon).

**Behavior (1d):**
- On mount / "Play again": the sticker drops (`stkDrop`) and the moment card bumps (`jarBump`,
  0.5s delay). Replay toggles a `show` flag off then back on after ~40ms to restart CSS animations.
- "Send one back" flips a `replied` boolean and updates the button label; disable/lock as suits the app.

---

## The Sticker Component (shared by 1b and 1d)

A puffy **die-cut badge**. See `Sticker.dc.html` for exact SVG path data per icon.

**Structure (per instance):**
- Outer ring: circle, diameter = `size` px, `background #FFFDF7`,
  `box-shadow 0 4px 9px rgba(34,48,74,.22)`, optional selection border
  `3px solid #4E9C94` (else `3px solid transparent`).
- Inner disc: circle, diameter = `round(size * 0.8)`, `overflow hidden`,
  `box-shadow inset 0 -3px 5px rgba(0,0,0,.16), inset 0 3px 4px rgba(255,255,255,.42)`.
  - **Flat sticker**: disc `background = accent color`.
  - **Holographic sticker**: disc is transparent; three stacked layers fill it:
    1. Rainbow foil: `conic-gradient(from 0deg, #ff8fbf, #ffd36e, #8be3a1, #6fd0e8, #b79bff, #ff8fbf)`,
       sized 160%×160% centered, `animation: spin 7s linear infinite` (rotate 0→360deg).
       Transform-only (GPU-composited) — do **not** animate background-position.
    2. Prism grid: `repeating-linear-gradient(62deg, rgba(255,255,255,.18) 0 2px, rgba(255,255,255,0) 2px 6px)` (static).
    3. Sheen: a 48%-wide vertical white gradient `linear-gradient(90deg, transparent, rgba(255,255,255,.85), transparent)`,
       `mix-blend-mode: screen`, `animation: sheen 3.4s ease-in-out infinite`
       (`translate3d(-160%…)` → `translate3d(180%…) skewX(-14deg)`). `will-change: transform`.
- Icon: inline SVG on a **24×24 viewBox**, rendered at `round(size * 0.56)` px, centered
  above the foil (`z-index 2`). White fill `#FFFDF7`, ink stroke `#22304A`,
  `stroke-width 1.7` (2 for some), round joins/caps. Some details use solid ink fill.

**Props:** `k` (icon key), `bg` (accent hex), `size` (px), `holo` (bool), `selected` (bool).

**The 24 icons (key → label):**
- Praise: `star`→Star work, `brill`→Brilliant★, `effort`→Great effort, `love`→Love this,
  `trophy`→Top marks, `crown`→Superstar★
- Skills: `sci`→Science, `write`→Writing, `maths`→Maths, `kind`→Kindness, `read`→Reading, `art`→Art
- Feelings: `smile`→Made me smile, `wow`→Wow!★, `proud`→So proud★, `laugh`→Made me laugh,
  `curious`→So curious, `brave`→So brave
- Milestones: `first`→First try, `finish`→You finished, `best`→Personal best★,
  `target`→Bullseye★, `mountain`→New heights, `levelup`→Levelled up

★ = holographic in the current design (`brill, crown, wow, proud, best, target`).

**Accent color assigned per sticker** (from the palette below) — see the `catalog()` method in
`Sticker Feedback.dc.html` for the exact `bg` per key.

---

## Interactions & Behavior (summary)
- **Peel-on (stkPop):** `transform: scale(0) rotate(-18deg)` → overshoot `scale(1.18)
  rotate(var(--tilt))` → settle `scale(1) rotate(var(--tilt))`. 0.5s `cubic-bezier(.34,1.4,.64,1)`.
- **Drop (stkDrop):** `translateY(-120px) rotate(-24deg) scale(.6) opacity 0` → land
  `translateY(0) rotate(-7deg) scale(1) opacity 1`. 0.9s `cubic-bezier(.34,1.4,.64,1)`.
- **Jar bump (jarBump):** small rotate wobble ±3deg, 1s, transform-origin top center.
- **Holo spin:** rotate 0→360deg, 7s linear infinite (transform only).
- **Holo sheen:** translate3d sweep, 3.4s ease-in-out infinite.
- Respect `prefers-reduced-motion`: the design disables all animations under that query.
- Focus: interactive controls use `outline: 3px solid #4E9C94; outline-offset: 2px` on
  `:focus-visible`.

## State Management
**1b:** active category tab (enum); array of placed stickers (max 4, each `{k, bg, holo}` +
assigned spot); note text. Derived: submit label, hint text, per-sticker `selected` flag.
**1d:** `show` (drives drop + bump; toggled to replay); `replied` boolean (Send one back).
In a real app, placement + note + "sent back" should persist to the moment/jar record and
sync to the child view.

## Design Tokens
**Palette**
- Canvas: `#EDE7D9`
- Surfaces: `#FAF6EE`, `#FFFDF7`; thumb/artwork band `#FBEED3`; note tab `#F3E3C3`
- Ink / text: `#22304A`; muted `#43506B`, `#6B7690`; on-dark muted `#A9B4C9`
- Borders: `#DFD6C0`, `#E4DCC8`; dashed dividers `#EDE4D2`
- Accents: `#F0B441` (yellow), `#E08A9B` (soft pink), `#C2476B` (rose), `#A6C979` (green),
  `#8AB9D6` (blue), `#4E9C94` (teal, primary CTA; shadow `#35706A`); rose CTA shadow `#93304F`
- Dark panel (1d): `#22304A`

**Typography**
- Display / headings / labels: **Fredoka** (400–700)
- Body / UI text: **Atkinson Hyperlegible** (400 / 700)
- Key sizes: h2 24px/600, card title 16–20px/600, body 13–21px, sheet label 11px/700,
  hint 12px/400.

**Radii:** buttons/pills 999px; cards 14–18px; inputs 10px; preview tile 14px; sticker discs 50%.

**Shadows:** card `0 12px 30px rgba(34,48,74,.10)`; sticker ring `0 4px 9px rgba(34,48,74,.22)`;
dropped sticker `0 6px 14px rgba(34,48,74,.28)`; button "press" `0 3px 0 <darker accent>`;
sticker disc inner `inset 0 -3px 5px rgba(0,0,0,.16), inset 0 3px 4px rgba(255,255,255,.42)`.

**Fonts import (Google Fonts):**
`Fredoka:wght@400;500;600;700` and `Atkinson+Hyperlegible:wght@400;700`.

## Assets
- **Sticker icons:** no external assets — all 24 are inline SVG (24×24 keyline). Copy the
  path data from `Sticker.dc.html` → `icon(k)`. Match Storyjar's broader icon set (single
  accent, ink outline, round joins).
- **Artwork thumbnails** in the mocks (rainbow / sunflower, etc.) are placeholders standing in
  for the child's real work image — wire these to actual uploaded media.
- Fonts: Fredoka + Atkinson Hyperlegible (Google Fonts), or the project's bundled equivalents.

## Files
- `Sticker Feedback.dc.html` — full design (options 1a–1d). **Implement the `#1b` and `#1d`
  sections.** Logic (`catalog()`, `renderVals()`) shows exact copy, accent assignments,
  placement spots, and state transitions.
- `Sticker.dc.html` — the reusable Sticker component: exact SVG path data for all 24 icons,
  die-cut badge structure, and the holographic layer/animation recipe.
- `support.js` — the prototype runtime (reference only; do not port).
