# Handoff: Storyjar — landing page, signup flow, core product screens & design system

## Overview
Storyjar (storyjar.co.uk) is a UK edtech product: a digital journal and portfolio for a primary-school class (ages 3–7, Reception/KS1). Children add "moments" (photos, drawings, typed words) which wait in a teacher approval queue; nothing joins a child's journal ("jar") until the teacher approves it. This handoff covers the marketing landing page, the teacher signup flow, the core product screens (child + teacher), the new management screens (class management, activity library, whole-school/staff admin, parent login), and the design-token system.

## ⚡ What changed in this update (implement these)
This revision responds to a round of product feedback. If you have already implemented the earlier package, these are the deltas:
1. **Signup step 1 — name capture reworked** (§2). Now a **Title** dropdown (Mr/Miss/Mrs/Ms/Mx, or "Prefer not to say") **+ full name**, then a choice of how the class addresses the teacher — *formal* (title + surname) or *first name* — with a live "Hello …" greeting preview. This fixes the bug where signup stored a raw name and the app greeted "Hello Mr". Persist `title`, `full_name`, and `display_style` ('formal' | 'first'); derive the greeting from these, never from a single free-text field.
2. **Drawing canvas — distinct nibs** (§5). The tool rail's near-identical emoji tools are replaced with four clearly different drawing tools: **Pen** (thin), **Felt tip** (thicker), **Highlighter** (translucent, wide), **Eraser** — each with a drawn nib icon and a sample stroke showing its true weight/opacity.
3. **NEW: Class management** (§9) — grid of class cards that open into that class's roster.
4. **NEW: Activity library** (§10) — folders + activity cards, each with a 3-dot actions menu. The menu is a dropdown that renders **above** the cards (not clipped inside the card) and is fully clickable — this was a reported bug.
5. **NEW: Whole-school / staff admin** (§11) — a **separate** admin space (ink-coloured chrome) for staff & school management. Flat model: teachers own their own classes/queues; admins manage staff, class assignment and billing and do **not** see children's work unless they teach the class.
6. **NEW: Parent login** (§12) — magic-link / family-code sign-in and a read-only parent home showing only their own child's approved moments.
7. **Teacher nav wiring**: the top-nav "Activities" and "My classes" tabs (previously dead `#anchors`) now route to the Activity Library and Class Management screens respectively.

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behaviour, **not production code to copy directly**. The task is to **recreate these designs in the target codebase: CodeIgniter 4 with server-rendered views, semantic HTML/CSS, and light vanilla JS** (no heavy front-end framework). Open each file in a browser to see the reference rendering; read its source for exact values. Ignore the prototype plumbing (`support.js`, `<x-dc>` wrappers, `sc-if`/`sc-for` tags, `{{ }}` holes, `browser-window.jsx` / tablet-bezel chrome) — these are prototype scaffolding only. The tablet bezels and browser chrome around product screens are presentation frames, not part of the product UI.

## Fidelity
**High-fidelity.** Colours, typography, spacing, radii, copy and interactions are final and should be recreated pixel-perfectly. All copy is UK English ("colour", "maths", "Reception") and uses the product vocabulary (see below).

## Product vocabulary (non-negotiable, used in ALL buttons/toasts/empty states)
- A piece of work = a **"moment"** (never "post"/"submission" in UI copy)
- A child's journal = their **"jar"**
- Child submitting = **"pop it in"** → toast "Popped in! Your teacher will see it soon."
- Teacher approval = **"add to the jar"** → toast "✓ Added to Poppy's jar"

## Design Tokens (declare as CSS custom properties on `:root`)

### Colours
- `--paper: #FAF6EE` — page background (warm off-white)
- `--cream: #FFFDF7` — cards/surfaces
- `--ink: #22304A` — text, 3px outlines, dark sections
- `--ink-soft: #43506B` — body copy
- `--muted: #6B7690` — metadata/captions
- `--glass: #4E9C94` — product colour: approve actions, focus rings, success
- `--glass-light: #D8ECE8` — jar glass fill, tints, chips (also `#EAF4F1` inside jar SVG)
- `--jam: #C2476B` — primary CTAs, celebration; press shadow `--jam-deep: #93304F`
- `--honey: #F0B441` — highlights, twinkles, waiting states (waiting tint `#FBEED3`, text on it `#8A5F1E`)
- `--kraft: #C9A87C` — jar lids, labels (tag fill `#F3E3C3`, twine/dark kraft `#A8854F`, lid rim `#B8945F`)
- Tile/avatar palette: `#E08A9B` pink, `#8AB9D6` blue, `#A6C979` green, plus jam/honey/glass; extras `#B99CD6`, `#E8A06A`
- Teacher-register calm border: `#E4DCC8`; error tint `#F7E0E6`

### Typography
- Display/buttons/headings: **Fredoka** (Google Fonts), weights 500–600
- Body/UI text: **Atkinson Hyperlegible** (Google Fonts), 400/700 — chosen for dyslexia-friendly legibility
- Scale: display 62/1.05 (hero h1); h1 34–44px; h2 24–30px; body 17/1.55 (teacher) and 24/1.5 (child screens); small 14–15px. Child screens use the SAME faces one size class larger — never a different font.

### Shape, space, elevation
- Radii: cards 16–20px, tiles/inputs 12px, pills/buttons 999px, tablet screens 20px
- Borders: child/marketing register `3px solid var(--ink)`; teacher register `2px solid #E4DCC8`
- Shadow: `0 4px 0 rgba(34,48,74,0.15)` (flat offset "pop", no blur); jam CTA `0 4px 0 #93304F`
- Spacing scale: 4/8/12/16/24/32/48/64/96
- Tilt: labels/tags ±1–2°, work tiles ±4–8°, hero jar −6°

### Motion
- Celebration tile drop: `cubic-bezier(.34,1.4,.64,1)`, ~0.9s; jar bump ±3°
- Hovers: lift 3–4px, 120ms
- Idle jar jiggle: 4.5s ease-in-out loop, ±2° around −6°
- `prefers-reduced-motion: reduce` → ALL animation off, final states shown (hero jar renders full)

## Screens / Views

### 1. Marketing landing page (`Storyjar Landing.dc.html`)
Single page, `--paper` background, max content width 1280px, 56px side padding.
- **Nav**: jar logo mark + lowercase "storyjar" wordmark (Fredoka 600 24px), links (How it works / Safeguarding / Pricing / FAQ, Atkinson 700 15px), outlined pill "Teacher sign in".
- **Hero (signature element)**: two-column grid (1.05fr/0.95fr). Left: uppercase aqua kicker "A CLASS JOURNAL FOR AGES 3–7"; h1 "Every child's story, collected." (Fredoka 600 62px) with a hand-drawn jam-red squiggle underline under "collected." (SVG path, 5px stroke); sub-paragraph; jam pill CTA "Start your class jar" + text link "See how it works →"; small line "Built by a serving UK primary teacher · No child emails or passwords, ever". Right: the **hand-inked jar SVG** (380×480, wobbly 7px ink outline, kraft domed lid with rim, twine + hanging kraft tag "Class 2M", glass shine strokes, honey four-point twinkles + stardust dots, a falling sun tile with dotted trail), tilted −6° with the idle jiggle.
- **Scroll-driven fill**: the hero section is a 220vh scroll track with a sticky 100vh stage. Nine work tiles (wobbly house, letter "a", scribble, flower, heart, "3+4", rainbow, "cat", moon) drop into the jar with a spring as the user scrolls the track (progress = scrolled fraction; tiles shown = round(progress × 9)). Tiles are VISIBLE by default in markup; JS hides them and reveals on scroll only when motion is allowed (progressive enhancement + reduced-motion fallback). "Scroll to fill the jar ↓" cue fades out at 100%.
- **How it works**: 3 cards (cream, 3px ink border, 18px radius, pop shadow), each with a tilted kraft step tag ("1 · Make", "2 · Approve", "3 · Treasure"), an illustration strip, Fredoka h3, body copy. Approval framed as the safety promise.
- **Feature sections** ×4, alternating text/visual, 110px gaps: drawing canvas, photo capture (two tilted polaroid cards with striped placeholder imagery + child-voice captions), activity library (3 list rows with status chips), approval queue (mini queue mock). Multi-class capability folded into the activities copy.
- **Safeguarding** (dark section, `--ink` bg): h2 "Our promises to your school" + "Not small print. The whole point." Four bordered promise cards with tilted coloured "Promise one…four" chips: no child emails/passwords ever; nothing exists until you approve it; UK GDPR + data in UK/EU; built by a serving UK primary teacher.
- **Parents teaser**: warm card, "Coming soon" pill, jar-with-heart illustration; mentions roadmap (voice/video, groups, scheduled activities).
- **Founder note**: cream card with washi-tape strip at top, first-person paragraph, signed "— A Year 2 teacher in the North East" (aqua Fredoka).
- **Pricing**: 2 cards. "One class jar" (cream) — Free forever, 4 ticked features. "School plan" (ink bg) — **£4.99 per teacher / month**, "billed annually · final pricing confirmed at launch", honey "Launch pricing" badge, jam CTA.
- **FAQ**: 6 native `<details>` accordions (cream, ink border), jam "+" chevron rotates 45° when open.
- **Final CTA + footer** (ink bg): centred CTA, footer links (Safeguarding/Privacy/Contact), "© 2026 Storyjar · storyjar.co.uk · Made in a Year 2 classroom".

### 2. Teacher signup flow (`Signup Flow.dc.html`)
Five single-screen steps, centred 620px card on `--paper`. Progress bar: five 12px pill segments that fill with tile colours (jam/honey/glass/blue/green) + mini jar icon + "Step N of 5".
1. **Your account** — **Title** select + **Full name** (side-by-side, Title ~150px), then **"What your class calls you"**: two selectable tiles — *formal* (`{title} {surname}`, e.g. "Mr Pearson") vs *first name* (e.g. "Sam"); selected tile gets `--glass-light` fill + ink border. Below: live line "Your class will be greeted with **'Hello {displayName}'**. You can change this later." Then school email, password. Reassurance: "Just you — **children never need accounts or emails.**" Derivation: split full name on whitespace → first = first token, surname = last token; formal = `title + ' ' + (surname||first)`; store `title`, `full_name`, `display_style`, and a computed `display_name`. This is the source of the app-wide greeting — do NOT greet from a single stored name string.
2. **Your school** — school name; Country + Year group selects (England/Scotland/Wales/NI/Elsewhere; Nursery→Year 2/Mixed).
3. **Name your class jar** — class name input (Fredoka 22px) with a LIVE kraft-tag preview of the jar label; button "Create class" (plain verbs, never "Submit").
4. **Add your class list** — textarea, one first name per line, paste-friendly. Aqua info strip: "**That's all we need.** No surnames required, no emails, no photos." + live count ("4 children so far.").
5. **Success** — honey badge "Your jar is ready! ✦"; the class code as six big tilted letter tiles (64×76px, Fredoka 44px, pastel fills, code format 3 consonants + 3 digits, e.g. "BKM347"); "🖨 Print for the classroom door" (window.print); "How your children sign in" panel: 3 pictured steps (type code → tap your name → make something); CTAs "Create your first activity" + "See what your children will see →".

Validation: inline, kind voice ("That email doesn't look quite right — check for typos."), jam text on `#F7E0E6`, `role="alert"`. Labels above fields, sentence case, keyboard-friendly.

### 3. Child login (`Child Login.dc.html`) — iPad landscape, 1180×800
Stage 1: centred jar logo, h1 "What's your class code?" (Fredoka 52px), sub "Your teacher will show you.", one huge forgiving input (420px, Fredoka 64px, letter-spacing 0.22em, uppercase, placeholder "ABC 123"), jam "Next →" (72px tall). Decorative twinkles.
Stage 2: kraft tag "Class 2M" + h1 "Tap your name!", "← Wrong class?" outline pill. 5-column grid of name cards: 76px coloured circle avatar with initial + first name (Fredoka 24px), cream card 3px ink border, min-height 150px, hover lifts 4px with −1° tilt. All targets ≥64px.

### 4. Child journal "My jar" (`Child Journal.dc.html`) — iPad landscape
- Header (cream, 3px ink bottom border): 64px avatar, "Poppy's jar" (Fredoka 28px) + "Class 2M"; right: mini jar icon + "12 moments" (aqua) + "Bye bye 👋" sign-out pill.
- **Add to my jar** card: three equal choices ≥88px tall — 📷 Photo (glass-light), 🖍 Drawing (honey tint), ⌨ My words (pink tint) — icon 38px + Fredoka 27px label.
- **Waiting strip**: honey tint, dashed kraft border, striped thumbnail, "My rainbow drawing — Waiting for your teacher to see it ⏳".
- **My moments** grid (3 cols): cream cards, 190px tinted thumbnail area with kind badge pill (photo/drawing/my words), title (Fredoka 21px), friendly date ("Tuesday 7 July").

### 5. Drawing canvas — entry state (`Drawing Canvas.dc.html`) — iPad landscape
- Left tool rail (150px, paper bg, 3px ink right border). Tools, each a rounded button that slides 8px right (lifted) with `--glass-light` tint + ink border when selected:
  - **Move** (arrow) — 118×60px, icon + "Move" label.
  - **Pen** — 118×84px. Drawn nib (slim glass-green barrel, ink tip, tilted −32°) above a **thin 3px** dark sample stroke; label "Pen".
  - **Felt tip** — same size. Fatter jam-red barrel + chisel tip above a **thick 8px** dark sample stroke; label "Felt tip".
  - **Highlighter** — honey chisel marker above a **wide 16px, 75%-opacity honey** sample stroke; label "Highlighter".
  - **Eraser** — pink block eraser with blue ferrule above a dashed "rubbing-out" sample; label "Eraser".
  - Divider, then a small row: **A** (text box) + **＋** (add shape/picture), both 54px.
  - Undo/redo (54px) pinned at the bottom.
  The four drawing tools MUST read as visually distinct (nib shape + stroke weight/opacity) — that is the point of this screen; do not fall back to lookalike emoji. Default selected tool: Pen.
- Top bar: avatar + "Poppy's drawing"; big glass-green "Done! ✓" pill (Fredoka 30px, ≥68px tall) top-right.
- Canvas: white, 3px ink border, 16px radius (child work-in-progress shown as reference).
- Bottom strip: rainbow gradient colour slider (26px tall, 3px ink border, 40px draggable thumb), 5 quick swatches (44px circles), 3 brush-size buttons (52px, selected has aqua tint), pages filmstrip (current page 64×48 + dashed "＋" add-page).

### 6. Submit moment (`Submit Moment.dc.html`) — 3 states
1. **Confirm**: h1 "Pop it in the jar?"; the work as a −2° polaroid (4px ink border, caption "Poppy's drawing"); buttons "Keep drawing" (muted outline) + "Pop it in the jar! 🫙" (jam, Fredoka 30px, ≥76px).
2. **Celebration**: a work tile drops into the jar (spring, 0.9s), jar bumps ±3° at 0.45s, twinkles pop at 0.9s; "Popped in!" (Fredoka 54px, glass green); "Your teacher will see it soon."; "Okay! →". Warm and complete — no confetti storms, no streaks.
3. **Waiting**: honey dashed strip "⏳ Waiting for your teacher to see it — It will join your jar when they've had a look." + "Back to my jar 🫙". Reduced motion: animations off, final layouts shown.

### 7. Teacher approval queue (`Teacher Approval Queue.dc.html`) — laptop
Calm register: `--paper` bg, cream surfaces, **2px `#E4DCC8` borders**, denser type (15–17px).
- Top bar (sticky): small logo, "Class 2M ▾" kraft class switcher, pill nav (Queue [count badge in jam] / Journals / Activities / My class), teacher avatar.
- Header row: "Waiting for you" + "5 moments from Class 2M"; right: "Select all" outline pill + "✓ Add {n|all} to their jars" glass pill (all pills `white-space: nowrap`).
- **Queue row**: checkbox (accent `--glass`; selecting turns row border aqua) · 84×64 tinted thumbnail · "Poppy · drawing" + activity context + time · skill-tag chips (toggle: idle cream/muted vs active aqua tint `#D8ECE8`/`#2E6B64`) · "✓ Add to jar" (glass) + "↩ Send back" (outline).
- **Send back** expands an inline note field below the row (dashed top border): placeholder "A kind note — e.g. 'Lovely! Can you add a label to your diagram?'" + jam "Send back".
- Approve/send-back removes the row and shows a **toast** (ink pill, bottom-centre, ~2.5s): "✓ Added to Poppy's jar" / "↩ Sent back to Poppy with your note" / "✓ 5 moments added to their jars".
- **Empty state**: jar illustration + "All caught up ☕ — Every moment is in its jar. Put the kettle on."
Everything ≤2 taps from the queue.

### 8. Design system reference (`Design System.dc.html`)
The token/component spec rendered as a page — colour cards, type scale, shape/motion tokens, component inventory (buttons, fields, kraft tag, avatar, moment card, queue row, toast, empty state), jar usage rules, accessibility floor. Treat it as the canonical written spec.

### 9. Class management (`Class Management.dc.html`) — laptop, teacher space
Teacher nav active tab "My classes". Two views toggled by client state (`openId`):
- **Cards view**: header "Your classes" + "{n} classes · tap a card to open its list" + jam "＋ New class". Grid of **3 class cards** (cream, 3px ink border, 18px radius, pop shadow, hover lift 3px). Each card: coloured top band (per-class tint) with a small jar mark, class name (Fredoka 24px) + year group, a jam "{n} waiting" badge pinned to the band's top-right (only if >0, `white-space:nowrap`), and a footer stats row — children count · in-the-jar total · "Open →". Per-class tints: 2M `#F3E3C3`/jam, Butterflies `#D8ECE8`/glass, Robins `#F7E0E6`/pink.
- **Detail / roster view**: "← All classes" back button; a tinted class header banner (jar mark, name, "{year} · {n} children · class code {CODE}", "⚙ Class settings" + jam "＋ Add child"). Then "Class list" ("sorted by first name") as a **2-col grid** of child rows: 46px coloured initial avatar, name (Atkinson 700 17px), "{n} moments · last {when}", optional pink "{n} waiting" chip, and "Journal →" link (→ Child Journal). Class = 2M/Butterflies/Robins, each with its own roster + code.

### 10. Activity library (`Activity Library.dc.html`) — laptop, teacher space
Teacher nav active tab "Activities". Two-column layout inside the app frame: **232px folders sidebar** (sticky) + main grid.
- **Folders sidebar**: "FOLDERS" label, then folder buttons (coloured square dot + name + count): All activities, Autumn term, Maths & number, Phonics & words, Free choice, Archived. Selected folder = kraft `#F3E3C3` fill. "＋ New folder" dashed button below. Selecting a folder filters the grid.
- **Activity grid** (2 cols): header = folder name + count + jam "＋ New activity". Each **activity card** (cream, 2px `#E4DCC8` border, 16px radius): 44px rounded type-icon tile (drawing `#FBEED3`/✏️, photo `#DEEAF3`/📷, words `#F7E0E6`/💬, free choice `#E5EED9`/🎨), title (Fredoka 19px) + type label, skill-tag chips (glass tint), and a footer line "Sent to {n} classes" / "Not sent to a class yet".
- **3-dot menu (the fix)**: a ⋯ button pinned top-right of each card. Clicking opens a **208px dropdown** (`position:absolute; top:50px; right:14px`) with menu items: ✎ Edit activity · ⧉ Duplicate · 🗂 Move to folder… · ➤ Send to a class · 🗑 Archive (jam text). **Critical:** the card must NOT clip the menu — the container has `overflow: visible`, the open card is raised (`z-index:20`) above its siblings, and the menu itself is `z-index:40` with a pop shadow. Only one menu open at a time; clicking the backdrop (the app root's onClick) closes it; clicks inside the menu stop propagation. Actions fire a toast (ink pill, bottom-centre). This replaces the earlier behaviour where the menu opened *inside* the card and was invisible/uninteractable.

### 11. Whole-school / staff admin (`School Admin.dc.html`) — laptop, SEPARATE admin space
Distinct from the teacher app — signalled by an **ink `--ink` top bar** (vs the teacher's cream bar) with an "ADMIN" honey badge and light-on-dark nav (Overview / **Staff** / Classes / Safeguarding / Billing) + "My teaching →" link back to the teacher view + admin avatar.
- Header: "St Bede's Primary" eyebrow, h1 "Staff & whole-school", jam "＋ Invite staff".
- **Stats strip** (4 cards): Staff `6` (1 invite pending), Classes `3`, Children `24` (no child logins), Seats used `6 / 10` (annual plan).
- **Staff table** (cream card, `overflow: visible` for menus): column headers Name / Role / Classes / Status / (actions). Each row: avatar + name ("· you" tag for the current admin) + email; **role pill** — Admin (pink `#F7E0E6`/jam), Teacher (glass `#D8ECE8`), Teaching assistant (green `#E5EED9`); assigned-class kraft chips (or "—"); status (green dot "Active" / honey dot "Invited"); a ⋯ menu (same overlay pattern as §10) with Edit role · Assign classes · Resend invite (invited only) · Remove from school (jam, hidden for "you"). "＋ Invite staff" and all row actions fire toasts.
- Footer note (implement as real policy): "Each teacher manages their own classes and approval queue. Admins can invite staff, assign classes and manage the school subscription — but never see children's work unless they teach the class." **This access rule is a requirement, not just copy.**

### 12. Parent login (`Parent Login.dc.html`) — families space
Separate family-facing space (url `storyjar.co.uk/family`), warm register, "FOR FAMILIES" glass badge. Client state toggles logged-out ↔ logged-in.
- **Logged out (sign in)**: two-column. Left: h1 "See your child's story", intro, an **email → "Email me a magic link"** flow (jam button; on send shows a glass confirmation strip with an "Open it now →" affordance that enters the app — represents clicking the emailed link), an "OR" divider, and "Use the family code from your letter" outline button. Copy: "No password needed. You'll only ever see **your own child** — set up by their school." Right: kraft panel with a tilted preview of a child's jar card. **No passwords** — magic link or teacher-issued family code only.
- **Logged in (parent home)**: cream header with logo + "Family" badge + a **child switcher** (pills, one per linked child — supports siblings; selected pill kraft-filled) + "Sign out". Body: kraft **jar hero** ("Hello, {child}'s grown-ups 👋", "{n} moments in the jar this term · in {class} with {teacher}", "↓ Download the term book"); a **teacher note** card (avatar + italic message); "Recently added" ("only moments the teacher has approved") as a **3-col grid** of moment cards (4:3 tinted thumbnail with type art, activity title, "{type} · {date}"). Footer: "Your child's storyjar is managed by their school. You can view and download, but only their teacher can add or change what's inside." **Parents are strictly read-only and scoped to their own child(ren).**

## Interactions & Behaviour summary
- Landing: scroll-fill hero (see above); FAQ accordions; smooth-scroll anchor nav.
- Signup: 5-step wizard, per-step validation, back/continue, generated class code, print.
- Child login: code → names → journal navigation.
- Canvas: tool selection lifts the active tool; Done → submit flow.
- Submit: confirm → celebration animation → waiting state.
- Queue: single approve, batch approve, skill-chip toggling, inline send-back note, toasts, empty state; "Activities"→library and "My classes"→class management nav.
- Class management: card grid ↔ roster detail toggle.
- Activity library: folder filter; per-card 3-dot dropdown (overlay above cards, single-open, backdrop-close); toasts.
- Admin: staff-row 3-dot dropdown (same overlay pattern); invite; toasts. Access rule enforced server-side (admins can't read children's work).
- Parent login: magic-link/family-code entry → read-only parent home; child switcher for siblings; sign out.

## State Management (server-rendered + light JS)
Most screens are plain server-rendered views. JS needed only for: hero scroll fill (~40 lines, scroll listener + rAF), signup step client validation, canvas tool selection highlight, submit-flow state transitions (or 3 server routes), queue approve/send-back (form posts or fetch + row removal + toast), FAQ (`<details>` is native).

## Accessibility floor (non-negotiable)
- Child touch targets ≥64px; teacher ≥40px
- Focus: 3–4px `#4E9C94` outline, 2–3px offset, on all focusables
- WCAG AA contrast minimum (ink on paper is 12.9:1)
- `prefers-reduced-motion` honoured everywhere; jar gets static filled fallback
- Semantic headings + landmarks; `role="alert"` on errors, `role="status"` on toasts
- Alt pattern: "Poppy's drawing: [title]"; decorative jars/twinkles `aria-hidden="true"`
- Child screens: one obvious next thing per screen, no dead ends; iPad landscape first, responsive everywhere
- No dark patterns: no urgency, scarcity, streaks or guilt copy

## Assets
- Fonts: Fredoka + Atkinson Hyperlegible via Google Fonts (self-host for production).
- The jar illustration is inline SVG in the prototypes — extract it once as a master SVG (outline, lid, twine, tag, tiles, twinkles as separate groups) and reuse at every size; never redraw per screen. Same for the small jar logo mark.
- Work-sample imagery: striped placeholder blocks labelled in monospace — replace with real (permissioned) children's work photos; never stock photography.
- Emoji used as child-facing icons (📷 🖍 ⌨ 🫙 ⏳ ☕) — acceptable at v1; replace with drawn icons in the brand style when available.

## Files
- `screenshots/` — reference PNGs of the updated & new screens (signup account step, drawing canvas, class management, activity library with 3-dot menu open, school admin with a row menu open, parent login, parent home). Rendered from the `.dc.html` prototypes; the laptop screens are taller than the frame so the PNGs show the top of each screen.
- `Storyjar Landing.dc.html` — landing page
- `Signup Flow.dc.html` — 5-step teacher signup **(updated: title + full name + display-style in step 1)**
- `Child Login.dc.html`, `Child Journal.dc.html`, `Submit Moment.dc.html` — child screens (in tablet-bezel presentation frames)
- `Drawing Canvas.dc.html` — child canvas **(updated: distinct pen / felt tip / highlighter / eraser nibs)**
- `Teacher Approval Queue.dc.html` — teacher queue **(updated: nav now routes to Activities & My classes)** (in a browser-chrome presentation frame; `browser-window.jsx` renders that frame — ignore it)
- `Class Management.dc.html` — **NEW** teacher class cards → roster
- `Activity Library.dc.html` — **NEW** folders + activity cards with overlay 3-dot menu
- `School Admin.dc.html` — **NEW** separate whole-school / staff admin (ink chrome)
- `Parent Login.dc.html` — **NEW** parent magic-link sign-in + read-only child jar
- `Design System.dc.html` — written token/component spec
- `browser-window.jsx` — presentation chrome for laptop screens; NOT part of the product UI
- `support.js` — prototype runtime only; not part of the design
